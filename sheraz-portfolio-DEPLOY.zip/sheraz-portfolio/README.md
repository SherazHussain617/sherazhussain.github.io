# Sheraz Hussain — Cybersecurity Professional Portfolio

Live portfolio website for **Sheraz Hussain** — SOC Analyst, DFIR Specialist, SOAR Engineer, and Penetration Tester.

## Live URL
[https://sherazhussain.github.io](https://sherazhussain.github.io)

## Files in this Package

| File | Purpose |
|------|---------|
| `index.html` | Main portfolio — fully self-contained single page |
| `404.html` | Custom 404 error page |
| `sitemap.xml` | Search engine sitemap (submit to Google Search Console) |
| `robots.txt` | Crawler rules — allows Google/Bing, blocks AI scrapers |
| `netlify.toml` | Netlify deployment config with security headers |
| `_headers` | Netlify/Cloudflare Pages HTTP security headers |
| `.htaccess` | Apache security headers (for cPanel shared hosting) |

## Deploy Options

### Option 1 — GitHub Pages (Free)
1. Create repo named `sherazhussain.github.io`
2. Upload all files (drag & drop or git push)
3. Settings → Pages → Branch: main → Save
4. Live at `https://sherazhussain.github.io`

### Option 2 — Netlify (Free, Recommended)
1. Go to [netlify.com](https://netlify.com) → New site
2. Drag & drop the entire folder
3. Done — live in under 60 seconds
4. `netlify.toml` applies security headers automatically

### Option 3 — Cloudflare Pages (Free)
1. Go to [pages.cloudflare.com](https://pages.cloudflare.com)
2. Connect GitHub repo or upload directly
3. `_headers` file applies security headers automatically

### Option 4 — cPanel/Shared Hosting
1. Upload all files to `public_html/`
2. `.htaccess` applies Apache security headers automatically

## Security Features Built In

- Content Security Policy (CSP) header
- X-Frame-Options: DENY (prevents clickjacking)
- X-Content-Type-Options: nosniff
- X-XSS-Protection
- Referrer-Policy
- Permissions-Policy (blocks camera/mic/geo access)
- HSTS (forces HTTPS) via server config files
- Right-click / context menu disabled
- F12 / Ctrl+Shift+I / Ctrl+U keyboard shortcuts blocked
- Copy/cut disabled on non-input elements
- DevTools size-based detection with overlay
- Anti-iframe (breaks out of frames)
- Console security warning
- Tab-hidden title watermark
- Bot/scraper blocking via .htaccess
- Hotlink protection via .htaccess
- AI training scraper exclusion via robots.txt

## After Deployment — SEO Steps

1. **Google Search Console**: Add property → verify → request indexing
   - https://search.google.com/search-console
2. **Bing Webmaster**: Submit sitemap
   - https://bing.com/webmasters
3. **LinkedIn**: Add portfolio URL to your profile
4. **Update canonical URL**: Replace `sherazhussain.github.io` with your actual domain in:
   - `index.html` (canonical + OG + JSON-LD)
   - `sitemap.xml`
   - `robots.txt`
   - `.htaccess` (hotlink protection)

## Contact
- Email: sheraztabish749@gmail.com
- LinkedIn: linkedin.com/in/sherazhussain-cyberexpert
- Phone: +92 332 625 7075
